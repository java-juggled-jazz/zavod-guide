@echo off
rem Zavod updater (docs/pack.md). Put next to mods\ in the game folder and run before playing.
setlocal
cd /d "%~dp0"
set "URL=https://java-juggled-jazz.github.io/zavod-guide/pack/pack.toml"
set "JAVA="
where java >nul 2>nul && set "JAVA=java"
if not defined JAVA if exist "%APPDATA%\.minecraft\runtime" for /r "%APPDATA%\.minecraft\runtime" %%j in (java.exe) do if exist "%%j" set "JAVA=%%j"
if not defined JAVA if exist "%APPDATA%\.tlauncher" for /r "%APPDATA%\.tlauncher" %%j in (java.exe) do if exist "%%j" set "JAVA=%%j"
if not defined JAVA goto nojava
if not exist "packwiz-installer-bootstrap.jar" goto noboot
if exist "packwiz.json" goto run
if not exist "mods" if not exist "saves" if not exist "versions" goto notgame
rem first run: old manual install -> backup (the updater only tracks files it installed itself)
set "BK=zavod-backup\before-updater-%RANDOM%%RANDOM%"
mkdir "%BK%"
if exist "mods" move "mods" "%BK%\mods" >nul
if exist "scripts" move "scripts" "%BK%\scripts" >nul
echo Old mods\ and scripts\ moved to %BK%
:run
"%JAVA%" -jar packwiz-installer-bootstrap.jar -s client "%URL%"
if errorlevel 1 goto fail
exit /b 0
:nojava
echo Java not found. Install Java 8+ (https://adoptium.net) or run the game once from your launcher.
goto fail
:noboot
echo packwiz-installer-bootstrap.jar must be next to this file.
goto fail
:notgame
echo This does not look like a game folder (no mods, saves, versions). Put the updater into the game folder.
:fail
pause
exit /b 1
