#!/bin/sh
# Zavod updater (docs/pack.md). Put next to mods/ in the game folder (or server folder) and run before playing.
#   ./zavod-update.sh          client
#   ./zavod-update.sh server   dedicated server (no GUI, client-only mods skipped)
cd "$(dirname "$0")" || exit 1
URL='https://java-juggled-jazz.github.io/zavod-guide/pack/pack.toml'
SIDE=client; GUI=
[ "$1" = server ] && { SIDE=server; GUI=-g; }
[ -z "$DISPLAY" ] && [ "$(uname)" != Darwin ] && GUI=-g
J="${JAVA:-java}"
command -v "$J" >/dev/null 2>&1 || { echo "Java not found (need Java 8+). Set JAVA=/path/to/java"; exit 1; }
[ -f packwiz-installer-bootstrap.jar ] || { echo "packwiz-installer-bootstrap.jar must be next to this script"; exit 1; }
if [ "$SIDE" = client ] && [ ! -d mods ] && [ ! -d saves ] && [ ! -d versions ] && [ ! -f packwiz.json ]; then
  echo "This does not look like a game folder (no mods/, saves/, versions/). Put the updater into the game folder."; exit 1
fi
# first run: old manual install -> backup (the updater only tracks files it installed itself)
if [ ! -f packwiz.json ] && { [ -d mods ] || [ -d scripts ]; }; then
  BK="zavod-backup/before-updater-$(date +%Y%m%d-%H%M%S)"; mkdir -p "$BK"
  for d in mods scripts; do [ -d "$d" ] && mv "$d" "$BK/"; done
  echo "Old mods/ and scripts/ moved to $BK"
fi
exec "$J" -jar packwiz-installer-bootstrap.jar $GUI -s "$SIDE" "$URL"
